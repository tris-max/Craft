// script.js for the pop up message
function showConfirm() {
    var result = confirm("Purchase Now?");
    if (result) {
      alert("Continue to the shopping site.");
    } else {
      alert("Thank you.");
    }
  }
  

